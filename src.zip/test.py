import numpy as np
print(np.random.uniform(0, 100))
